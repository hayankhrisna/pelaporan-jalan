<?php
ini_set("display_errors", 0);
session_start(); //memulai session
include "koneksi.php";

?>

<!doctype html>
<html lang="en">
  <head>
  	<title>Sidebar 01</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/detail.css">

  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="p-4 pt-5">
		  		<a href="#" class="img logo rounded-circle mb-5" style="background-image: url(img/add.png);"></a>
	        <ul class="list-unstyled components mb-5">
	          <li>
              <a href="halamanutama.php">Home</a>
	          </li>
	          <li>
	              <a href="#">About</a>
	          </li>
	          <li>
              <a href="input.php">Input Data</a>
	          </li>
	          <li>
              <a href="tabel.php">Tabel Data</a>
	          </li>
	        </ul>

	        <div class="footer">
	        	
	        </div>

	      </div>
    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5">

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">

            <button type="button" id="sidebarCollapse" class="btn btn-primary">
              <i class="fa fa-bars"></i>
              <span class="sr-only">Toggle Menu</span>
            </button>
            <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              &nbsp;&nbsp;&nbsp;<h1>DETAIL</h1>
              </ul>
            </div>
          </div>
        </nav>


        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <!-- form -->
              <div class="card">
                <div id="header">
                    <center>
                    <img src="img/logo1.jpeg" />
                    <img src="img/logo3.jpeg" />
                    <img src="img/logo2.jpeg" />
                  </div>
                  <hr size="3px">
                  <div id="header">
                    <center><h2> FOTO DOKUMENTASI</h2>
                  </div>
                  <hr size="3px">
                  <div id="anu">
                  <?php 
                            $data = mysqli_query($mysqli,"SELECT * FROM data_laporan WHERE id_laporan='$_GET[id]'"); // memberikan perintah query sql untuk menampilkan semua data di tabel jual
                            $datashow = mysqli_fetch_array($data);
                            //perintah untuk menampilkan semua data yang ada di tabel jual menggunakan perulangan
                             {
                            ?>
                      <table border="0" width="300">
                        <thead>
                          <tr>
                          <td>Nama Paket</td>
                          <td>:</td>
                          <td><?php echo $datashow['nama_paket']; ?></td>

                          </tr>
                          <tr>
                          <td>Kontraktor</td>
                          <td>:</td>
                          <td><?php echo $datashow['kontraktor']; ?></td>

                          </tr>
                          <tr>
                          <td>Konsultan Supervisi</td>
                          <td>:</td>
                          <td><?php echo $datashow['konsultan_supervisi']; ?></td>

                          </tr>
                          <tr>
                          <td>Tahun Anggaran</td>
                          <td>:</td>
                          <td><?php echo $datashow['tahun_anggaran']; ?></td>

                          </tr>
                          <tr>
                          <td>Gambar 0%</td>
                          <td>:</td>
                          <td><img src="img/<?php echo $datashow['gambar_0'];?>" alt="" class="image" width="200" height="150"> </td>

                          </tr>
                          <tr>
                          <td>Gambar 50%</td>
                          <td>:</td>
                          <td><img src="img/<?php echo $datashow['gambar_50'];?>" alt="" class="image" width="200" height="150"> </td>

                          </tr>
                          <tr>
                          <td>Gambar 100%</td>
                          <td>:</td>
                          <td><img src="img/<?php echo $datashow['gambar_100'];?>" alt="" class="image" width="200" height="150"> </td>

                          </tr>
                        </thead>
                        <?php } ?>

                        </table>
                        <style>
                          #anu{
                            padding-left: 30px;
                            padding-right: 30px;
                          }
                          </style>
                          
                    </div>
                  </div>
                  
            </div>
          </div>
        </div>

        </nav>

		</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>