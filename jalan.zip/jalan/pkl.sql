-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2020 at 09:33 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pkl`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_laporan`
--

CREATE TABLE `data_laporan` (
  `id_laporan` int(11) NOT NULL,
  `nama_paket` varchar(1000) NOT NULL,
  `kontraktor` varchar(1000) NOT NULL,
  `konsultan_supervisi` varchar(1000) NOT NULL,
  `tahun_anggaran` varchar(1000) NOT NULL,
  `nama_proyek` varchar(100) NOT NULL,
  `pekerjaan` varchar(100) NOT NULL,
  `lokasi` varchar(100) NOT NULL,
  `gambar_0` varchar(100) NOT NULL,
  `gambar_50` varchar(100) NOT NULL,
  `gambar_100` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_laporan`
--

INSERT INTO `data_laporan` (`id_laporan`, `nama_paket`, `kontraktor`, `konsultan_supervisi`, `tahun_anggaran`, `nama_proyek`, `pekerjaan`, `lokasi`, `gambar_0`, `gambar_50`, `gambar_100`) VALUES
(5, 'fara', 'fara', 'fara', '2010', 'fara uhuy', 'fara', 'fara', '', '', ''),
(6, 'lala', 'lili', 'lulu', '20920', 'lele', 'lolo', 'ulu', 'foto/1580722532.png', 'foto/1580722539.png', 'foto/1580722547.png'),
(7, 'daf', 'xbsj', 'asb', 'sbx', 'xb', 'xbn', 'vx', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `no_telp` varchar(12) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `no_telp`, `username`, `password`) VALUES
(1, 'fara', '081333770298', 'lala', '123'),
(2, 'Makta Ramadini', '081333770298', 'dini', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_laporan`
--
ALTER TABLE `data_laporan`
  ADD PRIMARY KEY (`id_laporan`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_laporan`
--
ALTER TABLE `data_laporan`
  MODIFY `id_laporan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
